export class Matrimonio {
    constructor(
        public _diaMatrimonio: string,
        public _mesMatrimonio: string,
        public _anioMatrimonio: string,
        public _nomPrimeraPersona: string,
        public _nomSegundaPersona: string,
        public _nomSacerdote: string,
        public _lugarParroquia:  string,
        public _nomTestigo1: string,
        public _nomTestigo2: string,
        public _numLibro: string,
        public _numFoja: string,
        public _numActa: string,
        public _notasMarginales: string,
        public _copia: string,
        public _fechaExp: any) 
    {

    }
}