export class Bautizo {
    constructor(
        public _diaBautizo: string,
        public _mesBautizo: string,
        public _anioBautizo: string,
        public _nomSacerdote: string,
        public _nomPersona: string,
        public _lugarNac:  string,
        public _fechaNac : any,
        public _nomPadre1: string,
        public _nomPadre2: string,
        public _nomPadrino1: string,
        public _nomPadrino2: string,
        public _numLibro: string,
        public _numFoja: string,
        public _numActa: string,
        public _notasMarginales: string,
        public _copia: string,
        public _fechaExp: any,
        public _genero: string) 
    {

    }
}