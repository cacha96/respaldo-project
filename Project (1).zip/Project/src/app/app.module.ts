import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {routing, appRoutingProviders} from './app.routing'
import {DatePipe} from '@angular/common'
import { FormsModule } from '@angular/forms';
import {NgxFsModule} from 'ngx-fs'
import {HttpClientModule} from '@angular/common/http'
import {DataTablesModule} from 'angular-datatables'
import {MomentModule} from 'angular2-moment'

import { AppComponent } from './app.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import {SidebarModule} from 'ng-sidebar';
import { ContentComponent } from './components/content/content.component';
import { DocumentComponent } from './components/document/document.component';
import { ErrorComponent } from './components/error/error.component';
import { BautizoComponent } from './components/bautizo/bautizo.component';
import { MatrimonioComponent } from './components/matrimonio/matrimonio.component';
import { ConsultaMatrimonioComponent } from './components/consulta-matrimonio/consulta-matrimonio.component';
import { ConsultaBautizoComponent } from './components/consulta-bautizo/consulta-bautizo.component';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    SidebarComponent,
    ContentComponent,
    DocumentComponent,
    ErrorComponent,
    BautizoComponent,
    MatrimonioComponent,
    ConsultaMatrimonioComponent,
    ConsultaBautizoComponent,
  ],
  imports: [
    BrowserModule,
    SidebarModule.forRoot(),
    routing,
    FormsModule,
    NgxFsModule,
    HttpClientModule,
    DataTablesModule,
    MomentModule
  ],
  providers: [appRoutingProviders, DatePipe],

  bootstrap: [AppComponent]
})
export class AppModule { }
