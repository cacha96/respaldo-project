//IMPORTAMOS LOS MODULOS DEL ROUTER DE ANGULAR
import {ModuleWithProviders} from '@angular/core'
//CLASES PARA GENERAR LAS RUTAS
import {Routes, RouterModule } from '@angular/router'
//Importar componentes a los que se le hara una pagina exclusiva

import {ErrorComponent} from './components/error/error.component'
import {BautizoComponent} from './components/bautizo/bautizo.component'
import {MatrimonioComponent} from './components/matrimonio/matrimonio.component'
import {ConsultaBautizoComponent} from './components/consulta-bautizo/consulta-bautizo.component'

//Arreglo de rutas
const appRoutes: Routes = [
    // {path: '', component: HomeComponent},
    {path: 'bautizo', component: BautizoComponent},
    {path: 'matrimonio', component: MatrimonioComponent},
    {path: 'consultaBautizo', component: ConsultaBautizoComponent},
    {path: '**', component: ErrorComponent}
];

export const appRoutingProviders: any[] = [];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
