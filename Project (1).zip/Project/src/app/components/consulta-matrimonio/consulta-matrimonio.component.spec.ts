import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaMatrimonioComponent } from './consulta-matrimonio.component';

describe('ConsultaMatrimonioComponent', () => {
  let component: ConsultaMatrimonioComponent;
  let fixture: ComponentFixture<ConsultaMatrimonioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaMatrimonioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaMatrimonioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
