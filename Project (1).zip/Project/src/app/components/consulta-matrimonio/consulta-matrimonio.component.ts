import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-matrimonio',
  templateUrl: './consulta-matrimonio.component.html',
  styleUrls: ['./consulta-matrimonio.component.css']
})
export class ConsultaMatrimonioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
