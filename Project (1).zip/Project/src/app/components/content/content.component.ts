import { Component, OnInit } from '@angular/core';
import {DatePipe} from '@angular/common'
import { FormsModule } from '@angular/forms'

// const PDFDocument = require('pdfkit')
  
@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  providers: [DatePipe]
})
export class ContentComponent implements OnInit {
  public myDay: number = this.getDay();
  public Month: string = this.getMonth();
  public Year: Object = new Date().getFullYear();

  constructor(private datePipe: DatePipe) { 

  
  }
  getDay(){
    var Wday: string[] = ["Sunday", "Monday", "Tuesday","Wednesday", "Thursday", "Friday", "Saturday"];
    var day = new Date();
    var Today2 = new Date();
    var dia =  Today2.getDate();
    // console.log('Dia', dia);
    return dia;
  }
  getMonth(){
    var WMonth: string[] = ["January", "February", "March","April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var Month = new Date();
    var TodayMonth = WMonth[Month.getMonth()];
    if(TodayMonth == 'January') return "Enero"
    else if(TodayMonth == "February") return "Febrero"
    else if(TodayMonth == "March") return "Marzo"
    else if(TodayMonth == "April") return "Abril"
    else if(TodayMonth == "May") return "Mayo"
    else if(TodayMonth == "June") return "Junio"
    else if(TodayMonth == "July") return "Julio"
    else if(TodayMonth == "August") return "Agosto"
    else if(TodayMonth == "September") return "Septiembre"
    else if(TodayMonth == "October") return "Octubre"
    else if(TodayMonth == "November") return "Noviembre"
    else if(TodayMonth == "December") return "Diciembre"
    else return TodayMonth
  }
  
  createPDF(){
   
  }

  ngOnInit() {
    
  }

}
