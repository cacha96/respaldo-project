import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ConsultaBautizo } from '../../models/consultaBautizo';
import { ConsultaBautizoService } from '../../services/consultaBautizo.service';
import Swal from 'sweetalert2';


declare var $;

@Component({
  selector: 'app-consulta-bautizo',
  templateUrl: './consulta-bautizo.component.html',
  styleUrls: ['./consulta-bautizo.component.css'],
  providers: [ConsultaBautizoService]
})
export class ConsultaBautizoComponent implements OnInit {
  public arrayBautizo: ConsultaBautizo[];
  public arrayBautizoId: ConsultaBautizo[];
  public cambio: boolean = false;

  constructor(private _consultaBautizoService: ConsultaBautizoService) {
    this.loadTableData();
    setTimeout(() => {
      $(() => {
        $('#dt').DataTable({
          "info": false,
          ordering: false,
          // scrollY: 400,
          processing: true,
          "oLanguage": {
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sSearch": "Buscar:",
            "oPaginate": {
              "sNext": ">",
              "sPrevious": "<"
            }
          }
        });
      })
    }, 1000)
  }
  ngOnInit() {

  }
  async loadTableData() {
    await this._consultaBautizoService.getActas().subscribe(
      response => {
        if (response) {
          this.arrayBautizo = response;
          // for(let i=0; i<this.arrayBautizo.length; i++){
          //   this.arrayBautizo[i]._fechaNac = this.arrayBautizo[i]._fechaNac.substring(0,10);
          //   var anio = this.arrayBautizo[i]._fechaNac.substring(0,4);
          //   var mes = this.arrayBautizo[i]._fechaNac.substring(5, 7)
          //   var dia = this.arrayBautizo[i]._fechaNac.substring(8, 10)
          //   var fechaNac = `${dia}/${mes}/${anio}`;
          //   this.arrayBautizo[i]._fechaNac = fechaNac;
          //   console.log(this.arrayBautizo[i]._fechaNac)
          // }
        }
      }, error => {

      }
    );
  }
  initTable() {
    console.log('Buenas noches');
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": true,
      processing: false,
      paging: true,
      searching: true,
      scrollY: 400,
      scrollX: true,
      "info": false,
      "ordering": false,
      "oLanguage": {
        "sLengthMenu": "Mostrar _MENU_ registros",
        "sSearch": "Buscar:",
        "oPaginate": {
          "sNext": "Siguiente",
          "sPrevious": "Anterior"
        }
      }
    })
  }

  async onEdit(id_bautizo) {
    this._consultaBautizoService.getActaBautizo(id_bautizo).subscribe(
      response => {
        if (response) {
          this.arrayBautizoId = response;
          // console.log(this.arrayBautizoId)
          this.arrayBautizoId[0]._fechaNac = this.arrayBautizoId[0]._fechaNac.substring(0, 10);
          this.arrayBautizoId[0]._fechaExp = this.arrayBautizoId[0]._fechaExp.substring(0, 10);
        }
      },
      error => {

      }
    )
    setTimeout(() => {
      this.cambio = true;
    }, 1000);
  }

  onSubmitEdit() {
    Swal.fire({
      title: '¿Desea confirmar la modificación?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#138496',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Cancelar',
      confirmButtonText: 'Si, modificarlo'
    }).then((result) => {
      if (result.value) {
        console.log(this.arrayBautizoId);
        this._consultaBautizoService.editActa(this.arrayBautizoId, this.arrayBautizoId[0].id_bautizo).subscribe(
          response => {
            console.log(response);
            // VOLVEMOS A CARGAR LOS DATOS DE LA TABLA
            this.loadTableData();
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: 'Your work has been saved',
              showConfirmButton: false,
              timer: 1500
            })

          }, error => {

          }
        )
      }
    })
  }

  onSubmitDelete(id_bautizo) {
    Swal.fire({
      title: '¿Eliminar el acta?',
      text: "No podrás revertir el cambio",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Eliminar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.value) {
        this._consultaBautizoService.deleteActa(id_bautizo).subscribe(
          response => {
            console.log(response)
            // VOLVEMOS A CARGAR LOS DATOS
            this.loadTableData();
            Swal.fire(
              'Eliminado',
              'Se ha eliminado el acta.',
              'success'
            )
          }, error => {

          }

        )

      }
    })
  }

  onCreatePDF(bautizo) {
    this._consultaBautizoService.createPDF(bautizo);
  }
}
