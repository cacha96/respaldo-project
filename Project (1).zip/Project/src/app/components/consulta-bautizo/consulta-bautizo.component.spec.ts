import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaBautizoComponent } from './consulta-bautizo.component';

describe('ConsultaBautizoComponent', () => {
  let component: ConsultaBautizoComponent;
  let fixture: ComponentFixture<ConsultaBautizoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaBautizoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaBautizoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
