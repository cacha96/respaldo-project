import { Component, OnInit } from '@angular/core';
import { MatrimonioService } from '../../services/matrimonio.service'
import { Matrimonio } from '../../models/matrimonio'

@Component({
  selector: 'app-matrimonio',
  templateUrl: './matrimonio.component.html',
  styleUrls: ['./matrimonio.component.css'],
  providers: [MatrimonioService] //SE IMPORT EL SERVICIO DENTRO DE LOS PROVIDERS 

})
export class MatrimonioComponent implements OnInit {
  public _day: string = this.getDay(); //VARIABLE QUE GUARDA EL DIA ACTUAL 
  public _month: string = this.getMonth(); // VARIABLE QUE GUARDA EL MES ACTUAL
  public _year: string = this.getYear(); //VARIABLE QUE GUARDA EL A;O ACTUAL 

  //VARIABLE QUE PERMITE CREAR UNA NUEVA ACTA
  public _actaMatrimonio: Matrimonio;

  constructor(
    private _matrimonioService: MatrimonioService //VARIABLE QUE GUARDA EL SERVICIO
  ) {
    this._actaMatrimonio = new Matrimonio(this._day, this._month, this._year, '', '', '', '', '', '', '', '', '', '', '', ''); //OBJETO NUEVO DE UN ACTA
  }
  ngOnInit() {
  }

  // METODO PARA GUARDAR EL A;O ACTUAL 
  getYear() {
    var year = new Date().getFullYear();
    return year.toString();
  }
  //  METODO PARA GUARDAR LA FECHA ACTUAL
  getDay() {
    var Wday: string[] = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var day = new Date();
    var Today2 = new Date();
    var dia = Today2.getDate();
    // console.log('Dia', dia);
    return dia.toString();
  }
  // METODO PARA GUARDAR EL MES ACTUAL
  getMonth() {
    var WMonth: string[] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var Month = new Date();
    var TodayMonth = WMonth[Month.getMonth()];
    if (TodayMonth == 'January') return "Enero"
    else if (TodayMonth == "February") return "Febrero"
    else if (TodayMonth == "March") return "Marzo"
    else if (TodayMonth == "April") return "Abril"
    else if (TodayMonth == "May") return "Mayo"
    else if (TodayMonth == "June") return "Junio"
    else if (TodayMonth == "July") return "Julio"
    else if (TodayMonth == "August") return "Agosto"
    else if (TodayMonth == "September") return "Septiembre"
    else if (TodayMonth == "October") return "Octubre"
    else if (TodayMonth == "November") return "Noviembre"
    else if (TodayMonth == "December") return "Diciembre"
    else return TodayMonth
  }
  // METODO ON SUBMIT SE ACTIVA CUANDO SE PRECIOSA EL BOTON PARA CREAR PDF
  onSubmit() {
    console.log(this._actaMatrimonio);
    this._matrimonioService.createActaMatrimonio(this._actaMatrimonio).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      }
    );
  }
}
