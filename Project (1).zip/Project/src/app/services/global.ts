export var Global = {
    url: 'http://localhost:3000/'
};

