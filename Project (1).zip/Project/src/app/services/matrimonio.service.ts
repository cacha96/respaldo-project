// IMPORTA INJECTABLE PARA INDICAR QUE ES UN SEVICIO
import { Injectable } from '@angular/core';
import { Matrimonio } from '../models/matrimonio';
// IMPORTAMOS HTTPCLIENT PARA UTILIZAR LA REST API 
import { HttpClient, HttpHeaders } from '@angular/common/http'
// IMPORTAMOS OBERSABLE PARA INDICAR QUE SE RECIBE INFORMACION DE LA REST API 
import { Observable } from 'rxjs'
//IMPORTA LA VARIABLE GLOBAL QUE PERMITE USAR LA URL 
import { Global } from './global'

@Injectable()
export class MatrimonioService {
    public url: string;

    constructor(private _http: HttpClient) {
        this.url = Global.url;
    }

    //METODO QUE PERMITE TRAER LA LISTA DE TODAS LAS ACTAS DE BAUTIZO 
    getActaMatrimonio(): Observable<any> {
        return this._http.get(this.url + 'bautizo')
    }

    //METODO QUE PERMITE CREAR UNA NUEVA ACTA DE BAUTIZO
    createActaMatrimonio(actaMatrimonio): Observable<any> {
        //SE CONVIERTE EL OBJETO A UN ARCHIVO JSON
        let _params = JSON.stringify(actaMatrimonio);
        let _headers = new HttpHeaders().set('Content-Type', 'application/json');

        //SE ENVIAN LOS PARAMETROS DEL OBJETO Y LOS HEADER PARA SER PROCESADOS POR EL BACKEND
        return this._http.post(this.url + 'matrimonio/insert', _params, { headers: _headers })
    }
}