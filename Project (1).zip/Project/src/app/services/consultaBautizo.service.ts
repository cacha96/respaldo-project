// IMPORTA INJECTABLE PARA INDICAR QUE ES UN SEVICIO
import { Injectable } from '@angular/core';
import { ConsultaBautizo } from '../models/consultaBautizo';
// IMPORTAMOS HTTPCLIENT PARA UTILIZAR LA REST API 
import { HttpClient, HttpHeaders } from '@angular/common/http'
// IMPORTAMOS OBERSABLE PARA INDICAR QUE SE RECIBE INFORMACION DE LA REST API 
import { Observable } from 'rxjs'
//IMPORTA LA VARIABLE GLOBAL QUE PERMITE USAR LA URL 
import { Global } from './global'
import jsPDF from 'jspdf';

@Injectable()
export class ConsultaBautizoService {
    public url: string;

    constructor(private _http: HttpClient) {
        this.url = Global.url;
    }

    //METODO QUE PERMITE TRAER LA LISTA DE TODAS LAS ACTAS DE BAUTIZO 
    getActas(): Observable<any> {
        return this._http.get(this.url + 'bautizo')
    }

    getActaBautizo(id_bautizo): Observable<any> {
        return this._http.get(this.url + 'bautizo/' + id_bautizo)
    }

    editActa(actaBautizo, id_bautizo): Observable<any> {
        let _params = JSON.stringify(actaBautizo);
        let _headers = new HttpHeaders().set('Content-Type', 'application/json');

        console.log('_params', _params);

        return this._http.put(this.url + 'bautizo/edit/' + id_bautizo, _params, { headers: _headers })
    }

    deleteActa(id_bautizo): Observable<any> {
        return this._http.delete(this.url + 'bautizo/delete/' + id_bautizo)
    }

    createPDF(bautizo) {
        console.log(bautizo);

        var doc = new jsPDF();

        // MEMBRETE INICIO 
        // ADD IMAGES
        var logo = new Image();
        logo.src = '../../assets/images/logoIglesia.jpg';
        doc.addImage(logo, 'JPEG', 18, 10, 23, 26);

        var virgen = new Image();
        virgen.src = '../../assets/images/logoVirgen.jpg';
        doc.addImage(virgen, 'JPEG', 168, 7, 18, 26);

        // AGREGAMOS bold A LA INFROMACION
        doc.setFontType('bold');
        doc.setFontSize(12);

        // dia bautizo
        doc.text(`${bautizo._diaBautizo}`, 55, 80);
        // mes bautizo
        doc.text(`${bautizo._mesBautizo}`, 77, 80);
        // anio bautizo
        doc.text(`${bautizo._anioBautizo}`, 130, 80);
        //nombre sacerdote
        doc.text(`${bautizo._nomSacerdote}`, 80, 88)
        // Nombre persona
        doc.text(`${bautizo._nomPersona}`, 60, 115);
        // lugar nacimiento
        doc.text(`${bautizo._lugarNac}`, 65, 128)

        // FECHA NACIMIENTO
        var fecha = this.findFecha(bautizo._fechaNac);
        doc.text(`${fecha._dia}`, 44, 136)
        doc.text(`${fecha._mes}`, 66, 136)
        doc.text(`${fecha._anio}`, 118, 136)

        // Nombre padres
        doc.text(`${bautizo._nomPadre1}`, 50, 144);
        doc.text(`${bautizo._nomPadre2}`, 45, 152);

        // Nombre padrinos
        doc.text(`${bautizo._nomPadrino1}`, 66, 160)
        doc.text(`${bautizo._nomPadrino2}`, 66, 168)

        // Num libros
        doc.text(`${bautizo._numLibro}`, 87, 176);
        doc.text(`${bautizo._numFoja}`, 120, 176);
        doc.text(`${bautizo._numActa}`, 155, 176);

        // notas marginales
        doc.text(`${bautizo._notasMarginales}`, 67, 190)

        //notas marginales
        doc.text(`${bautizo._copia}`, 35, 214);

        // copia para
        var fechaExp = this.findFecha(bautizo._fechaExp);
        doc.text(`${fechaExp._dia}`, 73, 227);
        doc.text(`${fechaExp._mes}`, 95, 227);
        doc.text(`${fechaExp._anio}`, 160, 227);


        doc.setFontSize(15);
        doc.text('DIÓCESIS DE CIUDAD VICTORIA, A. R', 60, 20)
        doc.setFontSize(12);
        doc.text('Parroquia de Nuestra Señora de Loreto', 70, 25)
        doc.setFontSize(9);

        doc.setFontType('normal');
        doc.text('Ciro R. de la Garza Treviño s/n C.P. 8840 Burgos, Tamps México. ', 60, 30)
        doc.text('Tel. (841) 844 40 14', 90, 35)
        // MEMBRETE FIN 

        // COPIA DE SIMPLE BAUTISMO
        doc.setFontSize(15);
        doc.text('COPIA DE SIMPLE BAUTISMO', 65, 55)

        doc.setFontSize(12);
        doc.text('El día', 40, 80)
        doc.text('_____', 52, 80)
        doc.text('de', 65, 80)
        doc.text('______________', 73, 80)
        doc.text('del año', 108, 80)
        doc.text('___________', 124, 80)
        doc.text(`fue bautizado`, 150, 80)

        // SEGUNDO RENGLON 
        doc.setFontSize(12);
        doc.text('en esta parroquia por el', 30, 88)
        doc.text('________________________________________________', 76, 88)

        // TERCER RENGLON
        if (bautizo._genero == 'niño') {
            doc.setFontSize(12);
            doc.text('un niño a quien se le puso por nombre:', 30, 96)
        }
        if (bautizo._genero == 'niña') {
            doc.setFontSize(12);
            doc.text('una niña a quien se le puso por nombre:', 30, 96)
        }
        // NOMBRE DEL NIÑO O NIÑA
        doc.setFontSize(12);
        doc.text('______________________________________________', 50, 115)
        doc.text('Nombre y Apellidos', 85, 120)

        // LUGAR NACIMIENTO
        doc.setFontSize(12);
        doc.text('Nació en', 40, 128)
        doc.text('________________________________________________________', 58, 128)

        // fecha nacimiento
        doc.text('el día', 30, 136)
        doc.text('_____', 42, 136)
        doc.text('de', 55, 136)
        doc.text('______________', 63, 136)
        doc.text('del año', 98, 136)
        doc.text('___________', 114, 136)

        // PADRES
        if (bautizo._genero == 'niño') {
            doc.setFontSize(12);
            doc.text('hijo de: ', 30, 144)
        }
        if (bautizo._genero == 'niña') {
            doc.setFontSize(12);
            doc.text('hija de: ', 30, 144)
        }
       
        doc.text('_____________________________________________________________', 45, 144)
        doc.text('y de: ', 30, 152)
        doc.text('_______________________________________________________________', 41, 152)

        // PADRINOS
        
        doc.text('fueron padrinos: ', 30, 160)
        doc.text('______________________________________________________', 62, 160)
        doc.text('______________________________________________________', 62, 168)

        // LIBRO FOJA ACTA
        doc.text('Como consta en el Libro No: ', 30, 176)
        doc.text('______', 85, 176)
        doc.text('Foja No:', 101, 176)
        doc.text('______', 118, 176)
        doc.text('Acta No:', 134, 176)
        doc.text('______', 152, 176)

        // NOTAS MARGINALES
        doc.text('Notas Marginales', 30, 190)
        doc.text('_____________________________________________________', 64, 190)
        doc.text('_____________________________________________________', 64, 198)

        // COPIA PARA 
        doc.text('La presente Copia de Bautismo se solicita para:', 30, 206)
        doc.text('____________________________________________________________________', 30, 214)

        // FECHA DE EXPEDICION
        doc.text('Fecha de Expedición', 30, 227)
        doc.text('______', 70, 227)
        doc.text('de', 86, 227)
        doc.text('_________________', 92, 227)
        doc.text('del año', 135, 227)
        doc.text('_____________', 150, 227)

        // DOY FE
        doc.text('Doy fe:', 135, 245)
        doc.text('Párroco', 134, 250)
        doc.text('_______________________________________', 95, 280)
        doc.save(`${bautizo._nomPersona}-${bautizo._diaBautizo}/${bautizo._mesBautizo}/${bautizo._anioBautizo}.pdf`);
    }

    findFecha(fechaNac) {
        var fecha: any = {
            _dia: '',
            _mes: '',
            _anio: ''
        }
        if (fechaNac.substring(5, 7) == '01') {
            fecha._mes = 'Enero';
        } else if(fechaNac.substring(5, 7) == '02'){
            fecha._mes = 'Febrero';
        }else if(fechaNac.substring(5, 7) == '03'){
            fecha._mes = 'Marzo';
        }else if(fechaNac.substring(5, 7) == '04'){
            fecha._mes = 'Abril';
        }else if(fechaNac.substring(5, 7) == '05'){
            fecha._mes = 'Mayo';
        }else if(fechaNac.substring(5, 7) == '06'){
            fecha._mes = 'Junio';
        }else if(fechaNac.substring(5, 7) == '07'){
            fecha._mes = 'Julio';
        }else if(fechaNac.substring(5, 7) == '08'){
            fecha._mes = 'Agosto';
        }else if(fechaNac.substring(5, 7) == '09'){
            fecha._mes = 'Septiembre';
        }else if(fechaNac.substring(5, 7) == '10'){
            fecha._mes = 'Octubre';
        }else if(fechaNac.substring(5, 7) == '11'){
            fecha._mes = 'Noviembre';
        }else if(fechaNac.substring(5, 7) == '12'){
            fecha._mes = 'Diciembre';
        }

        fecha._dia = fechaNac.substring(8, 10);
        fecha._anio = fechaNac.substring(0, 4);

        return fecha;
    }
}